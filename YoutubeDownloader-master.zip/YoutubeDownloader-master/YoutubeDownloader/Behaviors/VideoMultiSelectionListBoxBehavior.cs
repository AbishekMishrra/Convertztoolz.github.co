﻿using YoutubeExplode.Videos;

namespace YoutubeDownloader.Behaviors;

public class VideoMultiSelectionListBoxBehavior : MultiSelectionListBoxBehavior<IVideo>
{
}