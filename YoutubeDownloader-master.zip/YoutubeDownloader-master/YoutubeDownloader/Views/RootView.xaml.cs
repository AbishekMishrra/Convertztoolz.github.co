﻿namespace YoutubeDownloader.Views;

public partial class RootView
{
    public RootView()
    {
        InitializeComponent();
    }
}